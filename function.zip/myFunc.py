def lambda_handler(event, context):
   print("Hello from lambda")
   return 10